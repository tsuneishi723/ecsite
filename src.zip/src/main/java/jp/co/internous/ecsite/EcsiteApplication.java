package jp.co.internous.ecsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcsiteApplication.class, args);
	}

}
